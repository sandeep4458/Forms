import React from 'react'

function PersonalDetails() {
  return (
    <div className='formGroup'>
        <h3>please enter your details below</h3>
        <form>
<div className='formGroup'>
        <label htmlFor='nameInput' >Enter name</label>
        <input id="nameInput" type="text"></input>
        </div>
<div className='formGroup'>       
        <label htmlFor='numberInput'>number</label>
        <input id='numberInput' type="password"></input>
        </div>
 <div className='formGroup'>      
        <label htmlFor='emailInput'>email</label>
        <input id='emailInput' type="email"></input>
        </div>
 <div className='formGroup'>      
        <label htmlFor='birthdayInput'>birthday</label>
        <input id='birthdayInput' type="date"></input></div>
 <div className='formGroup'>  
        <label htmlFor='cityInput'>city</label>
        <input id='cityInput' type="text"></input>
        </div>
        <button>submit</button>
        
 









        </form>










    </div>
  )
}

export default PersonalDetails