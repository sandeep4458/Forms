import logo from './logo.svg';
import './App.css';
import PersonalDetails from './components/PersonalDetails';

function App() {
  return (
    <div className="App">
      <PersonalDetails/>
       
    </div>
  );
}

export default App;
